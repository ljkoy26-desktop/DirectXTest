﻿#include <windows.h>
#include <d3d8.h>
#include <mmsystem.h>
#include <wincodec.h>
#include <vector>

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

#pragma comment(lib, "d3d8.lib")
#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")

#define SCREEN_WIDTH  640
#define SCREEN_HEIGHT 480
#define PLAYER_SPEED  240.0f  // 초당 이동 픽셀 (프레임 속도에 무관하게 일정한 속도로 이동)
#define FULLSCREEN_MODE 0  // 1 = 풀스크린, 0 = 창 모드
#define FRAME_INTERVAL_MS 16  // 창 모드 Present는 수직동기화를 기다리지 않으므로 약 60FPS로 직접 제한
#define DIAGONAL_RELEASE_SEC 0.1f  // 대각선 키를 뗄 때 두 키가 떨어지는 시간 차를 허용하는 시간

// 로드카오스 스프라이트 (creature_17611.png 부터 순서대로)
// 방향 순서: 0=서, 1=남서, 2=남, 3=남동, 4=동, 5=북동, 6=북, 7=북서
// (예: 대기 동작 서=17611~17616, 남서=17617~17622, 남=17623~17628 ... 북서=17653~17658)
#define SPRITE_DIR_NAME      L"로드카오스"
#define SPRITE_FIRST_NUMBER  17611
#define SPRITE_DIR_COUNT     8
#define SPRITE_IDLE_FRAMES   6                                                     // 대기 동작 방향당 프레임 수
#define SPRITE_WALK_FRAMES   10                                                    // 걷기 동작 방향당 프레임 수
#define SPRITE_ATTACK_FRAMES 8                                                     // 공격 동작 방향당 프레임 수
#define SPRITE_IDLE_START    0                                                     // 대기 동작 0 ~ 47
#define SPRITE_WALK_START    (SPRITE_DIR_COUNT * SPRITE_IDLE_FRAMES)               // 걷기 동작 48 ~ 127
#define SPRITE_ATTACK_START  (SPRITE_WALK_START + SPRITE_DIR_COUNT * SPRITE_WALK_FRAMES)    // 공격 동작 128 ~ 191
#define SPRITE_FRAME_COUNT   (SPRITE_ATTACK_START + SPRITE_DIR_COUNT * SPRITE_ATTACK_FRAMES)
#define SPRITE_ANIM_FPS      12.0f
#define SPRITE_ATTACK_FPS    16.0f  // 공격 1회 = 8프레임 / 16 = 0.5초
#define SPRITE_HALF_WIDTH    40   // 화면 밖으로 나가지 않게 하는 여유 폭
#define SPRITE_HEIGHT        113  // 화면 밖으로 나가지 않게 하는 여유 높이

struct SpriteFrame
{
    LPDIRECT3DTEXTURE8 lpTexture;
    int                nWidth;         // 실제 그림 크기
    int                nHeight;
    int                nTextureWidth;  // 텍스처 크기 (2의 거듭제곱)
    int                nTextureHeight;
};

// 화면 좌표를 그대로 쓰는 정점 (변환/조명 없이 바로 그림)
struct SpriteVertex
{
    float fX, fY, fZ, fRHW;
    float fU, fV;
};

#define SPRITE_VERTEX_FVF (D3DFVF_XYZRHW | D3DFVF_TEX1)

LPDIRECT3D8           g_lpD3D         = NULL;
LPDIRECT3DDEVICE8     g_lpD3DDevice   = NULL;
LPDIRECTINPUT8        g_lpDI8         = NULL;
LPDIRECTINPUTDEVICE8  g_lpDIDKeyboard = NULL;
HWND                  g_hWnd          = NULL;
BOOL                  g_bActive       = FALSE;
SpriteFrame           g_aSpriteFrames[SPRITE_FRAME_COUNT];
float                 g_fPlayerX      = 0.0f;  // 캐릭터 발 위치 (가로 중앙)
float                 g_fPlayerY      = 0.0f;  // 캐릭터 발 위치 (아래쪽)
int                   g_nPlayerDir    = 2;     // 처음에는 남쪽(정면)을 바라봄
bool                  g_bPlayerWalk   = false;
bool                  g_bPlayerAttack = false;
float                 g_fAnimTime     = 0.0f;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
bool InitWindow(HINSTANCE hInstance, int nCmdShow);
bool InitDirect3D(HWND hWnd);
bool InitDirectInput(HWND hWnd);
bool LoadSprites();
bool RestoreDevice();
void UpdateInput(float fDeltaSec);
void DrawSprite(int nFrameIndex, int nFootX, int nFootY);
void RenderFrame();
void ReleaseSprites();
void ReleaseDirect3D();
void ReleaseDirectInput();

int main()
{
    HINSTANCE hInstance = GetModuleHandle(NULL);

    HRESULT hrCom = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);

    if (!InitWindow(hInstance, SW_SHOWDEFAULT))
    {
        return 1;
    }

    if (!InitDirect3D(g_hWnd))
    {
        ReleaseDirect3D();
        return 1;
    }

    if (!LoadSprites())
    {
        MessageBox(g_hWnd, TEXT("로드카오스 스프라이트를 불러오지 못했습니다."), TEXT("DirectX8 Sample"), MB_OK | MB_ICONERROR);
        ReleaseSprites();
        ReleaseDirect3D();
        return 1;
    }

    if (!InitDirectInput(g_hWnd))
    {
        ReleaseDirectInput();
        ReleaseSprites();
        ReleaseDirect3D();
        return 1;
    }

    timeBeginPeriod(1);

    MSG msg = { 0 };

    LARGE_INTEGER liFreq = { 0 };
    QueryPerformanceFrequency(&liFreq);

    LARGE_INTEGER liLastTick = { 0 };
    QueryPerformanceCounter(&liLastTick);

    while (msg.message != WM_QUIT)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            continue;
        }

        if (!g_bActive)
        {
            WaitMessage();
            QueryPerformanceCounter(&liLastTick);  // 비활성 동안 흐른 시간은 무시
            continue;
        }

        LARGE_INTEGER liNowTick = { 0 };
        QueryPerformanceCounter(&liNowTick);

        float fDeltaSec = static_cast<float>(liNowTick.QuadPart - liLastTick.QuadPart) / static_cast<float>(liFreq.QuadPart);

        if (fDeltaSec < FRAME_INTERVAL_MS / 1000.0f)
        {
            Sleep(1);
            continue;
        }

        liLastTick = liNowTick;

        if (fDeltaSec > 0.1f)
        {
            fDeltaSec = 0.1f;  // 창을 끌거나 할 때 멈췄던 시간만큼 순간이동하지 않도록
        }

        UpdateInput(fDeltaSec);
        RenderFrame();
    }

    timeEndPeriod(1);

    ReleaseDirectInput();
    ReleaseSprites();
    ReleaseDirect3D();

    if (SUCCEEDED(hrCom))
    {
        CoUninitialize();
    }

    return static_cast<int>(msg.wParam);
}

bool InitWindow(HINSTANCE hInstance, int nCmdShow)
{
    WNDCLASSEX wc = { 0 };
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
    wc.lpszClassName = TEXT("DirectX8SampleWndClass");

    if (!RegisterClassEx(&wc))
    {
        return false;
    }

#if FULLSCREEN_MODE
    DWORD dwStyle = WS_POPUP;
    RECT rcWindow = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
#else
    DWORD dwStyle = WS_OVERLAPPEDWINDOW;
    RECT rcWindow = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
    AdjustWindowRect(&rcWindow, dwStyle, FALSE);
#endif

    g_hWnd = CreateWindowEx(
        0,
        wc.lpszClassName,
        TEXT("DirectX8 Sample"),
        dwStyle,
        CW_USEDEFAULT, CW_USEDEFAULT,
        rcWindow.right - rcWindow.left, rcWindow.bottom - rcWindow.top,
        NULL, NULL, hInstance, NULL);

    if (g_hWnd == NULL)
    {
        return false;
    }

    ShowWindow(g_hWnd, nCmdShow);
    UpdateWindow(g_hWnd);
    g_bActive = TRUE;
    return true;
}

bool InitDirect3D(HWND hWnd)
{
    g_lpD3D = Direct3DCreate8(D3D_SDK_VERSION);

    if (g_lpD3D == NULL)
    {
        return false;
    }

    D3DDISPLAYMODE d3ddm = { 0 };
    HRESULT hr = g_lpD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);

    if (FAILED(hr))
    {
        return false;
    }

    D3DPRESENT_PARAMETERS d3dpp = { 0 };
    d3dpp.Windowed         = !FULLSCREEN_MODE;
    d3dpp.SwapEffect       = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    d3dpp.BackBufferWidth  = SCREEN_WIDTH;
    d3dpp.BackBufferHeight = SCREEN_HEIGHT;

    hr = g_lpD3D->CreateDevice(
        D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        hWnd,
        D3DCREATE_SOFTWARE_VERTEXPROCESSING,
        &d3dpp,
        &g_lpD3DDevice);

    if (FAILED(hr))
    {
        return false;
    }

    return true;
}

bool InitDirectInput(HWND hWnd)
{
    HRESULT hr = DirectInput8Create(
        GetModuleHandle(NULL),
        DIRECTINPUT_VERSION,
        IID_IDirectInput8,
        reinterpret_cast<void**>(&g_lpDI8),
        NULL);

    if (FAILED(hr))
    {
        return false;
    }

    hr = g_lpDI8->CreateDevice(GUID_SysKeyboard, &g_lpDIDKeyboard, NULL);

    if (FAILED(hr))
    {
        return false;
    }

    hr = g_lpDIDKeyboard->SetDataFormat(&c_dfDIKeyboard);

    if (FAILED(hr))
    {
        return false;
    }

    hr = g_lpDIDKeyboard->SetCooperativeLevel(hWnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);

    if (FAILED(hr))
    {
        return false;
    }

    g_lpDIDKeyboard->Acquire();

    g_fPlayerX = static_cast<float>(SCREEN_WIDTH) / 2.0f;
    g_fPlayerY = static_cast<float>(SCREEN_HEIGHT + SPRITE_HEIGHT) / 2.0f;
    return true;
}

// 실행 파일 위치에서 위로 올라가며 스프라이트 폴더를 찾는다 (VS 디버깅/직접 실행 모두 대응)
bool FindSpriteDirectory(WCHAR* pszOutDir)
{
    WCHAR szBase[MAX_PATH] = { 0 };
    GetModuleFileNameW(NULL, szBase, MAX_PATH);

    for (int nDepth = 0; nDepth < 8; ++nDepth)
    {
        WCHAR* pSlash = wcsrchr(szBase, L'\\');

        if (pSlash == NULL)
        {
            break;
        }

        *pSlash = L'\0';

        WCHAR szTest[MAX_PATH] = { 0 };
        wsprintfW(szTest, L"%s\\%s\\creature_%05d.png", szBase, SPRITE_DIR_NAME, SPRITE_FIRST_NUMBER);

        if (GetFileAttributesW(szTest) != INVALID_FILE_ATTRIBUTES)
        {
            wsprintfW(pszOutDir, L"%s\\%s", szBase, SPRITE_DIR_NAME);
            return true;
        }
    }

    return false;
}

int NextPowerOfTwo(int nValue)
{
    int nResult = 1;

    while (nResult < nValue)
    {
        nResult <<= 1;
    }

    return nResult;
}

// WIC로 PNG를 읽어 A8R8G8B8 텍스처에 올린다.
// 오래된 그래픽 카드는 2의 거듭제곱 크기 텍스처만 지원하므로 텍스처를 크게 만들고 남는 부분은 투명으로 채운다.
// MANAGED 풀은 장치 Reset 후에도 자동 복구되므로 다시 올릴 필요가 없다.
bool LoadSpriteTexture(IWICImagingFactory* pFactory, const WCHAR* pszPath, SpriteFrame& frame)
{
    IWICBitmapDecoder*     pDecoder   = NULL;
    IWICBitmapFrameDecode* pFrame     = NULL;
    IWICFormatConverter*   pConverter = NULL;
    std::vector<DWORD>     vecPixels;
    UINT                   uWidth     = 0;
    UINT                   uHeight    = 0;

    HRESULT hr = pFactory->CreateDecoderFromFilename(pszPath, NULL, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &pDecoder);

    if (SUCCEEDED(hr))
    {
        hr = pDecoder->GetFrame(0, &pFrame);
    }

    if (SUCCEEDED(hr))
    {
        hr = pFactory->CreateFormatConverter(&pConverter);
    }

    if (SUCCEEDED(hr))
    {
        // WIC의 32bppBGRA는 메모리 배치가 D3DFMT_A8R8G8B8 과 같다
        hr = pConverter->Initialize(pFrame, GUID_WICPixelFormat32bppBGRA, WICBitmapDitherTypeNone, NULL, 0.0, WICBitmapPaletteTypeCustom);
    }

    if (SUCCEEDED(hr))
    {
        hr = pConverter->GetSize(&uWidth, &uHeight);
    }

    if (SUCCEEDED(hr))
    {
        vecPixels.resize(uWidth * uHeight);
        hr = pConverter->CopyPixels(NULL, uWidth * 4, uWidth * uHeight * 4, reinterpret_cast<BYTE*>(vecPixels.data()));
    }

    if (pConverter != NULL) pConverter->Release();
    if (pFrame     != NULL) pFrame->Release();
    if (pDecoder   != NULL) pDecoder->Release();

    if (FAILED(hr))
    {
        return false;
    }

    frame.nWidth         = static_cast<int>(uWidth);
    frame.nHeight        = static_cast<int>(uHeight);
    frame.nTextureWidth  = NextPowerOfTwo(frame.nWidth);
    frame.nTextureHeight = NextPowerOfTwo(frame.nHeight);

    hr = g_lpD3DDevice->CreateTexture(frame.nTextureWidth, frame.nTextureHeight, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &frame.lpTexture);

    if (FAILED(hr))
    {
        return false;
    }

    D3DLOCKED_RECT lockedRect = { 0 };
    hr = frame.lpTexture->LockRect(0, &lockedRect, NULL, 0);

    if (FAILED(hr))
    {
        return false;
    }

    for (int y = 0; y < frame.nTextureHeight; ++y)
    {
        DWORD* pDst = reinterpret_cast<DWORD*>(static_cast<BYTE*>(lockedRect.pBits) + y * lockedRect.Pitch);

        for (int x = 0; x < frame.nTextureWidth; ++x)
        {
            pDst[x] = (x < frame.nWidth && y < frame.nHeight) ? vecPixels[y * frame.nWidth + x] : 0;
        }
    }

    frame.lpTexture->UnlockRect(0);
    return true;
}

bool LoadSprites()
{
    WCHAR szDir[MAX_PATH] = { 0 };

    if (!FindSpriteDirectory(szDir))
    {
        return false;
    }

    IWICImagingFactory* pFactory = NULL;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pFactory));

    if (FAILED(hr))
    {
        return false;
    }

    bool bResult = true;

    for (int i = 0; i < SPRITE_FRAME_COUNT; ++i)
    {
        WCHAR szPath[MAX_PATH] = { 0 };
        wsprintfW(szPath, L"%s\\creature_%05d.png", szDir, SPRITE_FIRST_NUMBER + i);

        if (!LoadSpriteTexture(pFactory, szPath, g_aSpriteFrames[i]))
        {
            bResult = false;
            break;
        }
    }

    pFactory->Release();
    return bResult;
}

bool RestoreDevice()
{
    if (g_lpD3DDevice == NULL)
    {
        return false;
    }

    D3DDISPLAYMODE d3ddm = { 0 };
    HRESULT hr = g_lpD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);

    if (FAILED(hr))
    {
        return false;
    }

    D3DPRESENT_PARAMETERS d3dpp = { 0 };
    d3dpp.Windowed         = !FULLSCREEN_MODE;
    d3dpp.SwapEffect       = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    d3dpp.BackBufferWidth  = SCREEN_WIDTH;
    d3dpp.BackBufferHeight = SCREEN_HEIGHT;

    hr = g_lpD3DDevice->Reset(&d3dpp);

    if (FAILED(hr))
    {
        return false;
    }

    return true;
}

void UpdateInput(float fDeltaSec)
{
    if (g_lpDIDKeyboard == NULL)
    {
        return;
    }

    BYTE abKeyState[256] = { 0 };
    HRESULT hr = g_lpDIDKeyboard->GetDeviceState(sizeof(abKeyState), abKeyState);

    if (FAILED(hr))
    {
        g_lpDIDKeyboard->Acquire();
        return;
    }

    if (abKeyState[DIK_ESCAPE] & 0x80)
    {
        PostMessage(g_hWnd, WM_CLOSE, 0, 0);
        return;
    }

    // 입력 방향 -> 스프라이트 방향 (0=서, 1=남서, 2=남, 3=남동, 4=동, 5=북동, 6=북, 7=북서)
    static const int s_anDirTable[3][3] =
    {
        //  x=-1  x=0  x=+1
        {   7,    6,   5 },  // y=-1 (위)
        {   0,   -1,   4 },  // y= 0
        {   1,    2,   3 },  // y=+1 (아래)
    };

    int nDirX = 0;
    int nDirY = 0;

    if (abKeyState[DIK_LEFT]  & 0x80) nDirX -= 1;
    if (abKeyState[DIK_RIGHT] & 0x80) nDirX += 1;
    if (abKeyState[DIK_UP]    & 0x80) nDirY -= 1;
    if (abKeyState[DIK_DOWN]  & 0x80) nDirY += 1;

    // 대각선 키 두 개는 정확히 동시에 떼어지지 않는다.
    // 대각선 입력 직후 잠깐(DIAGONAL_RELEASE_SEC) 한쪽 키만 남은 경우는 키를 떼는 중으로 보고 대각선 방향을 유지한다.
    static float s_fSinceDiagonal = DIAGONAL_RELEASE_SEC;
    static int   s_nLastDiagX     = 0;
    static int   s_nLastDiagY     = 0;

    if (nDirX != 0 && nDirY != 0)
    {
        s_fSinceDiagonal = 0.0f;
        s_nLastDiagX     = nDirX;
        s_nLastDiagY     = nDirY;
    }
    else
    {
        s_fSinceDiagonal += fDeltaSec;
    }

    int nFaceDir = s_anDirTable[nDirY + 1][nDirX + 1];  // -1 = 방향키 없음

    bool bReleasingDiagonal = (s_fSinceDiagonal < DIAGONAL_RELEASE_SEC) &&
                              ((nDirX == 0 && nDirY == s_nLastDiagY) || (nDirY == 0 && nDirX == s_nLastDiagX));

    if (bReleasingDiagonal)
    {
        nFaceDir = s_anDirTable[s_nLastDiagY + 1][s_nLastDiagX + 1];
    }

    // 공격 중에는 동작이 끝날 때까지 이동/방향 전환 없이 공격 동작만 재생
    if (g_bPlayerAttack)
    {
        g_fAnimTime += fDeltaSec;

        if (g_fAnimTime * SPRITE_ATTACK_FPS >= SPRITE_ATTACK_FRAMES)
        {
            g_bPlayerAttack = false;
            g_bPlayerWalk   = false;
            g_fAnimTime     = 0.0f;
        }

        return;
    }

    // A 키를 누르면 공격 시작 (누르고 있으면 연속 공격).
    // 방향키를 같이 누르고 있으면 그 방향으로 돌아서 공격한다.
    if (abKeyState[DIK_A] & 0x80)
    {
        if (nFaceDir >= 0)
        {
            g_nPlayerDir = nFaceDir;
        }

        g_bPlayerAttack = true;
        g_bPlayerWalk   = false;
        g_fAnimTime     = 0.0f;
        return;
    }

    // 대각선 이동 시 속도가 빨라지지 않도록 1/√2 배
    float fMove = PLAYER_SPEED * fDeltaSec;

    if (nDirX != 0 && nDirY != 0)
    {
        fMove *= 0.70710678f;
    }

    g_fPlayerX += nDirX * fMove;
    g_fPlayerY += nDirY * fMove;

    if (g_fPlayerX < SPRITE_HALF_WIDTH)
    {
        g_fPlayerX = static_cast<float>(SPRITE_HALF_WIDTH);
    }

    if (g_fPlayerX > SCREEN_WIDTH - SPRITE_HALF_WIDTH)
    {
        g_fPlayerX = static_cast<float>(SCREEN_WIDTH - SPRITE_HALF_WIDTH);
    }

    if (g_fPlayerY < SPRITE_HEIGHT)
    {
        g_fPlayerY = static_cast<float>(SPRITE_HEIGHT);
    }

    if (g_fPlayerY > SCREEN_HEIGHT)
    {
        g_fPlayerY = static_cast<float>(SCREEN_HEIGHT);
    }

    int  nNewDir  = nFaceDir;
    bool bNewWalk = (nNewDir >= 0);

    if (bNewWalk != g_bPlayerWalk || (bNewWalk && nNewDir != g_nPlayerDir))
    {
        g_fAnimTime = 0.0f;  // 동작이나 방향이 바뀌면 애니메이션을 처음부터
    }

    if (bNewWalk)
    {
        g_nPlayerDir = nNewDir;
    }

    g_bPlayerWalk = bNewWalk;
    g_fAnimTime  += fDeltaSec;
}

// 발 위치(가로 중앙, 아래쪽)를 기준으로 스프라이트를 그린다
void DrawSprite(int nFrameIndex, int nFootX, int nFootY)
{
    SpriteFrame& frame = g_aSpriteFrames[nFrameIndex];

    if (frame.lpTexture == NULL)
    {
        return;
    }

    // D3D8은 픽셀 중심이 0.5 어긋나 있으므로 -0.5 해서 텍스처 픽셀과 화면 픽셀을 1:1로 맞춘다
    float fLeft   = static_cast<float>(nFootX - frame.nWidth / 2) - 0.5f;
    float fTop    = static_cast<float>(nFootY - frame.nHeight) - 0.5f;
    float fRight  = fLeft + frame.nWidth;
    float fBottom = fTop + frame.nHeight;

    // 2의 거듭제곱 텍스처 중 실제 그림이 있는 부분만 사용
    float fMaxU = static_cast<float>(frame.nWidth) / frame.nTextureWidth;
    float fMaxV = static_cast<float>(frame.nHeight) / frame.nTextureHeight;

    // 삼각형 스트립 순서: 좌상, 우상, 좌하, 우하
    SpriteVertex aVertices[4] =
    {
        { fLeft,  fTop,    0.0f, 1.0f, 0.0f,  0.0f  },
        { fRight, fTop,    0.0f, 1.0f, fMaxU, 0.0f  },
        { fLeft,  fBottom, 0.0f, 1.0f, 0.0f,  fMaxV },
        { fRight, fBottom, 0.0f, 1.0f, fMaxU, fMaxV },
    };

    g_lpD3DDevice->SetTexture(0, frame.lpTexture);
    g_lpD3DDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, aVertices, sizeof(SpriteVertex));
}

void RenderFrame()
{
    if (g_lpD3DDevice == NULL)
    {
        return;
    }

    HRESULT hr = g_lpD3DDevice->TestCooperativeLevel();

    if (hr == D3DERR_DEVICELOST)
    {
        return;
    }

    if (hr == D3DERR_DEVICENOTRESET)
    {
        RestoreDevice();
        return;
    }

    static DWORD dwColorIndex = 0;
    dwColorIndex = (dwColorIndex + 1) % 256;

    g_lpD3DDevice->Clear(
        0, NULL,
        D3DCLEAR_TARGET,
        D3DCOLOR_XRGB(dwColorIndex, 0, 255 - dwColorIndex),
        1.0f, 0);

    if (FAILED(g_lpD3DDevice->BeginScene()))
    {
        return;
    }

    // 스프라이트 그리기 상태 (장치 Reset 시 초기화되므로 매 프레임 설정)
    g_lpD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    g_lpD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    g_lpD3DDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
    g_lpD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);                // PNG 알파값으로 반투명 블렌딩
    g_lpD3DDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    g_lpD3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);   // 텍스처 색을 그대로
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_POINT);     // 도트 그림이 번지지 않도록
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_POINT);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_ADDRESSU, D3DTADDRESS_CLAMP);
    g_lpD3DDevice->SetTextureStageState(0, D3DTSS_ADDRESSV, D3DTADDRESS_CLAMP);
    g_lpD3DDevice->SetVertexShader(SPRITE_VERTEX_FVF);                           // D3D8은 FVF를 SetVertexShader로 지정

    // 내가 이동할 수 있는 로드카오스 캐릭터 (멈춰 있으면 대기, 움직이면 걷기, A 키는 공격)
    int nActionStart = g_bPlayerWalk ? SPRITE_WALK_START  : SPRITE_IDLE_START;
    int nActionCount = g_bPlayerWalk ? SPRITE_WALK_FRAMES : SPRITE_IDLE_FRAMES;
    int nAnimFrame   = static_cast<int>(g_fAnimTime * SPRITE_ANIM_FPS) % nActionCount;

    if (g_bPlayerAttack)
    {
        // 공격은 반복하지 않고 한 번만 재생 (마지막 프레임에서 멈춤)
        nActionStart = SPRITE_ATTACK_START;
        nActionCount = SPRITE_ATTACK_FRAMES;
        nAnimFrame   = static_cast<int>(g_fAnimTime * SPRITE_ATTACK_FPS);

        if (nAnimFrame >= SPRITE_ATTACK_FRAMES)
        {
            nAnimFrame = SPRITE_ATTACK_FRAMES - 1;
        }
    }

    int nFrameIndex = nActionStart + g_nPlayerDir * nActionCount + nAnimFrame;

    DrawSprite(nFrameIndex, static_cast<int>(g_fPlayerX), static_cast<int>(g_fPlayerY));

    g_lpD3DDevice->EndScene();
    g_lpD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void ReleaseSprites()
{
    for (int i = 0; i < SPRITE_FRAME_COUNT; ++i)
    {
        if (g_aSpriteFrames[i].lpTexture != NULL)
        {
            g_aSpriteFrames[i].lpTexture->Release();
            g_aSpriteFrames[i].lpTexture = NULL;
        }
    }
}

void ReleaseDirect3D()
{
    if (g_lpD3DDevice != NULL)
    {
        g_lpD3DDevice->Release();
        g_lpD3DDevice = NULL;
    }

    if (g_lpD3D != NULL)
    {
        g_lpD3D->Release();
        g_lpD3D = NULL;
    }
}

void ReleaseDirectInput()
{
    if (g_lpDIDKeyboard != NULL)
    {
        g_lpDIDKeyboard->Unacquire();
        g_lpDIDKeyboard->Release();
        g_lpDIDKeyboard = NULL;
    }

    if (g_lpDI8 != NULL)
    {
        g_lpDI8->Release();
        g_lpDI8 = NULL;
    }
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE)
    {
        PostMessage(hWnd, WM_CLOSE, 0, 0);
        return 0;
    }

    if (uMsg == WM_ACTIVATEAPP)
    {
        g_bActive = static_cast<BOOL>(wParam);
        return 0;
    }

    if (uMsg == WM_DESTROY)
    {
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
